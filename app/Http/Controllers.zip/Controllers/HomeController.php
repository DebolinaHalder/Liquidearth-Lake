<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\GaugeReading;
use App\Gauge;
use GuzzleHttp\Client;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
   /* public function __construct()
    {
        $this->middleware('auth');
        redirect("login");
    }*/

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::check()) {
            return view('home.home');
        }
    }
    public function gen_Index(){
        return view('home.gen_index');
    }

    public function load_weather_data(){
        $readings = GaugeReading::all();
        foreach ($readings as $reading){
            if(!strcmp($reading->precipi , "NA")) {
                $gauge = Gauge::find($reading->gauge_inc_id);

                $sep_date = explode('-', $reading->date);
                $date_format_for_api = $sep_date[0] . $sep_date[1] . $sep_date[2];

                $url = "http://api.wunderground.com/api/06864078c3f10b7a/history_";
                $url .= $date_format_for_api;
                $url .= "/q/NC/";
                $url .= $gauge->city;
                $url .= ".json";

                $client = new Client();
                $response = $client->get($url);
                $decoded_response = json_decode($response->getBody());

                $precipi = $decoded_response->history->dailysummary[0]->precipi;
                $input = ['precipi' => $precipi];
                GaugeReading::find($reading->id)->update($input);



            }
        }
    }


}
