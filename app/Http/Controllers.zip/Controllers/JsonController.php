<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Gauge;

class JsonController extends Controller
{
    public function getAllGauges(){
        $gauges = Gauge::where("city","like","%NC")->get();
        return $gauges;
    }

    public function getAllGaugesWA(){
        $gauges = Gauge::where("city","like","%WA")->get();
        return $gauges;
    }



}
