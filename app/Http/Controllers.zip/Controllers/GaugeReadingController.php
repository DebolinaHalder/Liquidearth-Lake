<?php

namespace App\Http\Controllers;

use App\Problem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use App\Gauge;
use App\GaugeReading;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;

class GaugeReadingController extends Controller
{
    public function index(){

        //$readings = GaugeReading::orderBy('created_at','desc')->get();
        $readings=DB::select("SELECT * FROM gauges, gauge_readings WHERE gauges.id=gauge_readings.gauge_inc_id");
        return view('readings.index', ['readings' => $readings]);
    }
    public function create($id){
        //load form view
        $gauge = Gauge::findOrFail($id);
        //print_r($gauge);
        return view('readings.create',['gauge' => $gauge]);
    }

    //for google map
    public function map_create($id){
        //load form view
        $gauge = Gauge::findOrFail($id);
        return view('readings.mapcreate',['gauge' => $gauge]);
    }
    public function map_store(Request $request)
    {
        $input = $request->all();
        GaugeReading::create($input);

        if($input['is_bubble_level_okay']== "No"){

            $gauge_id_name = explode(':',$input['gauge_name']);
            $input_problem=['gauge_id'=>$gauge_id_name[0],'date'=>$input['date'],'time'=>$input['time'],'problem'=>"Bubble level is not okay"];
            Problem::create($input_problem);
            $data = array('name'=>"Citizen Science",'gauge_id'=>$gauge_id_name[0],'date'=>$input['date'],'time'=>$input['time'],'problem'=>"Bubble level is not okay");
            Mail::send(['text'=>'mail'], $data, function($message) {
                $message->to('armanbd7@gmail.com', 'Admin')->subject
                ('Gauge problem');
                $message->from('testarman445@gmail.com','Citizen Science');
            });


        }
        Session::flash('flash_message', 'The measurement is added successfully');
       // return redirect()->route('gauges.details',$input['gauge_inc_id']);
    }


    public function store(Request $request)
    {
        /*$this->validate($request, array(
                'title' => 'required',
                'slug' => 'required',
                'short_description' => 'required',
                'full_content' => 'required',
            )
        );*/

        $input = $request->all();

        GaugeReading::create($input);

        if($input['is_bubble_level_okay']== "No"){

            $gauge_id_name = explode(':',$input['gauge_name']);
            $input_problem=['gauge_id'=>$gauge_id_name[0],'date'=>$input['date'],'time'=>$input['time'],'problem'=>"Bubble level is not okay"];
            Problem::create($input_problem);
            $data = array('name'=>"Citizen Science",'gauge_id'=>$gauge_id_name[0],'date'=>$input['date'],'time'=>$input['time'],'problem'=>"Bubble level is not okay");
            Mail::send(['text'=>'mail'], $data, function($message) {
                $message->to('armanbd7@gmail.com', 'Admin')->subject
                ('Gauge problem');
                $message->from('testarman445@gmail.com','Citizen Science');
            });


        }

        Session::flash('flash_message', 'The measurement is added successfully');

        //return redirect()->back();
        //return redirect('news');
       return redirect()->route('gauges.details',$input['gauge_inc_id']);
    }
    //
    public function report_problem(Request $request){
        $input=$request->all();
        $gauge_id_name = explode(':',$input['gauge_id']);
        $input['gauge_id']=$gauge_id_name[0];
        print_r($input);
        Problem::create($input);

        $data = array('name'=>"Citizen Science",'gauge_id'=>$gauge_id_name[0],'date'=>$input['date'],'time'=>$input['time'],'problem'=>$input['problem']);

        Mail::send(['text'=>'mail'], $data, function($message) {
            $message->to('armanbd7@gmail.com', 'Admin')->subject
            ('Gauge problem');
            $message->from('testarman445@gmail.com','Citizen Science');
        });
        return redirect()->route('readings.gaugeselect');

    }

    public function edit($id){
        //$reading=DB::select("SELECT * FROM gauges, gauge_readings where gauges.id=gauge_inc_id and gauge_readings.id={$id}");
        if(Auth::check()) {
            $reading = DB::table('gauges')
                ->join('gauge_readings', 'gauge_readings.gauge_inc_id', '=', 'gauges.id')
                ->where('gauge_readings.id', '=', $id)
                ->first();
            // print_r($reading);
            return view('readings.edit', ['reading' => $reading,]);
        }
        else{
            return redirect('login');
        }
    }

    public function update($id,Request $request){


        $reading = GaugeReading::findOrFail($id);
        $input = $request->all();
        //print_r($input);

        GaugeReading::find($id)->update($input);

        //store status message
        Session::flash('flash_message', 'Measurement updated successfully!');
        return redirect()->route('gauges.details',$reading->gauge_inc_id);
    }

    public function delete($id)
    {
        $reading = GaugeReading::findOrFail($id);
        // delete
        GaugeReading::find($id)->delete();
        Session::flash('flash_message', 'Successfully deleted the Measurement!');
        return redirect()->route('gauges.details',$reading->gauge_inc_id);
    }

    public function view_problem(){
        if(Auth::check()) {
            $problems = Problem::orderBy('created_at', 'desc')->get();
            return view('readings.problem', ['problems' => $problems]);
        }
        else{
            return redirect('login');
        }

    }
    public function gauge_select(){
        $gauges = Gauge::where("city","like","%NC")->orderBy('name', 'asc')->get();
     
        return view('readings.gaugeselect',['gauges' => $gauges]);
    }
    public function gauge_select_map(){
        $gauges = Gauge::where("city","like","%NC")->orderBy('gauge_id', 'asc')->get();
        return view('readings.gaugeselectmap',['gauges' => $gauges]);
    }

    /////*****************************************Start Washington*****************************
    public function gauge_select_wa(){
        $gauges = Gauge::where("city","like","%WA")->orderBy('name', 'asc')->get();
        return view('readings.gaugeselectwa',['gauges' => $gauges]);
    }
    public function gauge_select_map_wa(){
        $gauges = Gauge::where("city","like","%WA")->orderBy('gauge_id', 'asc')->get();
        return view('readings.gaugeselectmapwa',['gauges' => $gauges]);
    }

    ///   ####################################### End Washington ##############################

}
